import pytest
import allure
from locators.locators import demo
from pages.sky import LogInPage
from allure_commons.types import AttachmentType
from utils.util_function import highlight

@pytest.mark.usefixtures("setup")
class TestLogIn:

    @allure.title("Validate the home and deal page of the application")
    @allure.description("Verify the navigation of home and deal page")
    def test_page_navigation(self):
        log_in_page = LogInPage(self.driver)
        log_in_page.open_page()
        log_in_page.acceptCookies()
        log_in_page.open_deal_page()
        log_in_page.verifyTheURL()


    @allure.title("Validate the login page of the application with credential")
    @allure.description("Validate the login page of the application with credential")
    def test_login_passed(self):
        log_in_page = LogInPage(self.driver)
        log_in_page.open_page()
        log_in_page.acceptCookies()
        log_in_page.loginInvalidError()
        allure.attach(self.driver.get_screenshot_as_png(), name="Login_Error",
                      attachment_type=AttachmentType.PNG)

    @allure.title("Verify the searching functionality")
    @allure.description("Verify the searching functionality")
    def test_verifySearchingFunctionality(self):
        log_in_page = LogInPage(self.driver)
        log_in_page.open_page()
        log_in_page.acceptCookies()
        log_in_page.verifySearching()
        log_in_page.verifyEditorialSection()
        allure.attach(self.driver.get_screenshot_as_png(), name="Editorial",
                      attachment_type=AttachmentType.PNG)
