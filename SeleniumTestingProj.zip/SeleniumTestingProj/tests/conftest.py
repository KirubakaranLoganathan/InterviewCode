import allure
import pytest
from allure_commons.types import AttachmentType
from utils.driver_factory import DriverFactory
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

@pytest.fixture()
def setup(request):

    driver = DriverFactory.get_driver()
    driver.implicitly_wait(5)
    driver.maximize_window()

    #WebDriverWait(driver, 10).until(EC.alert_is_present())
    #alert = driver.switch_to.alert
    # driver.find_element_by_xpath('//*[@id="uc-btn-accept-banner"]').text

    request.cls.driver = driver
    before_failed = request.session.testsfailed
    yield
    if request.session.testsfailed != before_failed:
        allure.attach(driver.get_screenshot_as_png(), name="Test failed", attachment_type=AttachmentType.PNG)
    #driver.quit()
