from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
import os

class DriverFactory:

    @staticmethod
    def get_driver():
        return webdriver.Chrome(
            executable_path= os.path.abspath("browserDriver/chromedriver.exe"))

        raise Exception("Provide valid driver name")


