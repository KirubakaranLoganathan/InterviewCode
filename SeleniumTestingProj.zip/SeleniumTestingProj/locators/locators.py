from selenium.webdriver.common.by import By


class demo:
    frameid = (By.ID,"sp_message_iframe_450949")
    accept = (By.XPATH,"//*[@class = 'message-component message-row unstack']/button[2]")
    username = (By.XPATH, '//*[@id="username"]')
    password = (By.XPATH, '//*[@id="password"]')
    loginbtn = (By.XPATH, '//*[@id="signinButton"]')
    deal = (By.XPATH,"//*[@href='https://www.sky.com/shop/offers']")
    signIn = (By.XPATH,'//*[@id="masthead"]/div[4]/a')
    login_Error = (By.XPATH,'//*[@id="pageContentWrapper"]/div[3]/div[2]/p')
    searchIcon = (By.XPATH,'//*[@id="masthead-search-toggle"]')
    searchtextbox = (By.XPATH,'//*[@id="masthead-navigation"]/div/div[1]/div[2]/div/div/div/div/div/div/div/input')
    searchbtn = (By.XPATH,'//*[@id="masthead-navigation"]/div/div[1]/div[2]/div/div/div/div/div/div/div/button')
    editorialSection = (By.XPATH,'//*[@id="polaris"]/div/div/div/section[1]/div/div/div/div')