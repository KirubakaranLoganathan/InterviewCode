import logging

import allure
from selenium.webdriver.common.keys import Keys
from locators.locators import demo
from utils.util_function import highlight
from selenium.webdriver.common.action_chains import ActionChains
class LogInPage:

    def __init__(self, driver):
        self.driver = driver
        self.logger = logging.getLogger(__name__)

    @allure.step("Given I am on the home page")
    def open_page(self):
        # self.logger.info("Given I am on the home page")
        self.driver.get("https://www.sky.com/")

    @allure.step("Accept the cookies")
    def acceptCookies(self):
        iframe_ = self.driver.find_element(*demo.frameid)
        self.driver.switch_to.frame(iframe_)
        self.driver.find_element(*demo.accept).click()
        self.driver.switch_to.default_content()
    @allure.step("When I navigate to ‘Deals’")
    def open_deal_page(self):
        self.driver.find_element(*demo.deal).click()

    @allure.step("Then the user should be on the 'https://www.sky.com/deals' page")
    def verifyTheURL(self):
        url = self.driver.current_url
        assert url == 'https://www.sky.com/deals'


    @allure.step("When I try to sign in with invalid credentials")
    def loginInvalidError(self):
        self.driver.find_element(*demo.signIn).click()
        self.driver.find_element(*demo.username).send_keys("test")
        self.driver.find_element(*demo.password).send_keys("test")
        self.driver.find_element(*demo.loginbtn).click()

    @allure.step("Then I should see a text saying that ‘Sorry, we need to check you're a genuine user’")
    def verifyLoginInvalidError(self):
        verifyError = self.driver.find_element(*demo.login_Error).text
        assert verifyError.strip() == "Sorry, we need to check you're a genuine user"

    @allure.step("When I search ‘sky’ in the search bar")
    def verifySearching(self):
        self.driver.find_element(*demo.searchIcon).click()
        self.driver.find_element(*demo.searchtextbox).send_keys("TV")
        self.driver.implicitly_wait(5)
        element = self.driver.find_element(*demo.searchbtn)
        action = ActionChains( self.driver)
        action.double_click(on_element=element)
        action.perform()

    @allure.step("Then I should see an editorial section")
    def verifyEditorialSection(self):
        self.driver.implicitly_wait(5)
        ele = self.driver.find_element(*demo.editorialSection)
        highlight(ele)




